public class Ex3 {
    public static void main(String[] args) {
        int i;
        for (i = 0; i < 100; i++) {
            System.out.println("Number " + i);
            // System.out.println("Let's go to the next loop");
        }
        System.out.println(i);
    }
}
