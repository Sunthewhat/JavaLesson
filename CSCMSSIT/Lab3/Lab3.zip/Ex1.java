/**
 * Ex1
 */
public class Ex1 {

    public static void main(String[] args) {
        int x = 1;
        int sum = 0;
        while (++x <= 50)
            ;
        System.out.println(sum);
        System.out.println(x);
    }
}