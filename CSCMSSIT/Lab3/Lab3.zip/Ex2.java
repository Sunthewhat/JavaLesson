public class Ex2 {
    public static void main(String[] args) {
        int x = 0;
        // int sum = 0;
        do {
            x++;
            System.out.println(x);
        } while (x <= 50);
    }
}
