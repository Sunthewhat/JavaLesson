import java.util.*;

public class MyHelloWorld {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String x = sc.next();
        System.out.println(x);
        String w = sc.next();
        System.out.println(w);
        String y = sc.next();
        System.out.println(y);
        String z = sc.next();
        System.out.println(z);
    }
}
