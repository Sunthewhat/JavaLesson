import java.util.*;

public class Ex3 {
    public static void main(String[] args) {
        // String st1 = new String("HELLO");
        // String st2 = "Hello";
        // st2 = st1;
        // System.out.println(st1 == st2);
        // System.out.println(st1.compareTo(st2));
        // System.out.println(st1.compareToIgnoreCase(st2));
        String st1 = new String("cat");
        String st2 = "catfish";
        System.out.println(st1.compareTo(st2));
    }
}
