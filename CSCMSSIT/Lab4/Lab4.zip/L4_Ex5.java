public class L4_Ex5 {
    public static void main(String[] args) {
        // String[] fruits = new String[3];
        // fruits[0] = new String("Apple");
        // fruits[1] = "Banana";
        // fruits[2] = new String("Mango");
        String[] fruits = { new String("Apple"), new String("Banana"), new String("Mango") };
        System.out.println(fruits[0] + " " + fruits[1] + " " + fruits[2]);
    }
}
