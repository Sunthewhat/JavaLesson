public class L4_Ex4 {
    public static void main(String[] args) {
        int[] myNumbers = { 10, 15, 18, 132, 0 };
        System.out.println(myNumbers[3]);
        System.out.println((myNumbers[3] + 2) / 4);
        if (myNumbers[3] > 100) {
            System.out.println("The value is greater than 100");
        }
    }
}
