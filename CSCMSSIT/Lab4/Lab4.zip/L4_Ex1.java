/**
 * Ex1
 */
public class L4_Ex1 {

    public static void main(String[] args) {
        int[] myNumbers;
        double[] myDouble;
        char myChar[];

        myNumbers = new int[5];
        myDouble = new double[10];
        myChar = new char[5];
        boolean mybool[] = new boolean[5];
    }
}