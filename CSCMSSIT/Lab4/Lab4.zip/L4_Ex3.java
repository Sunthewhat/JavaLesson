public class L4_Ex3 {
    public static void main(String[] args) {
        int[] myNumbers = { 10, 15, 18, 132, 0 };
        System.out.println(myNumbers[0]);
        System.out.println(myNumbers[1]);
        System.out.println(myNumbers[2]);
        System.out.println(myNumbers[3]);
        System.out.println(myNumbers[4]);
        System.out.println(myNumbers.length);
    }
}
