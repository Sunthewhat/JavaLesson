public class L4_Ex2 {
    public static void main(String[] args) {
        int[] myNumbers = { 10, 15, 18, 132, 0 };
        for (int i : myNumbers) {
            System.out.println(i);
        }
        // double[] myDouble;
        // char myChar[];

        // myNumbers = new int[5];
        // myDouble = new double[10];
        // myChar = new char[5];
        // boolean mybool[] = new boolean[5];
        // System.out.println(myNumbers[0]);
        // System.out.println(myDouble[1]);
        // System.out.println(myChar[2]);
        // System.out.println(mybool[3]);
        // System.out.println(myNumbers[0]);
        // myNumbers[0] = 128;
        // System.out.println(myNumbers[0]);
        // System.out.println(myNumbers[5]);
    }
}
