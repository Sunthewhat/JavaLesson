public class L4_Ex7 {
    public static void main(String[] args) {
        // int[][] numTable = new int[2][3];
        // numTable[0][0] = 1;
        // numTable[0][1] = 2;
        // numTable[0][2] = 3;
        // numTable[1][0] = 4;
        // numTable[1][1] = 5;
        // numTable[1][2] = 6;
        int[][] numTable = { { 1, 2, 3 }, { 4, 5, 6 } };
        System.out.println(numTable.length);
        System.out.println(numTable[0].length);
        System.out.println(numTable[1].length);
    }
}
