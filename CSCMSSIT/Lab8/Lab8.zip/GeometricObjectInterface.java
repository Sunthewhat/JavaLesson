public interface GeometricObjectInterface {
    public static final String color = "white";

    public abstract double getArea();

    public abstract double getPerimeter();
}
