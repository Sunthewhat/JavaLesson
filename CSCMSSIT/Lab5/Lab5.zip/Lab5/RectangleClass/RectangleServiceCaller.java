public class RectangleServiceCaller {
    public static void main(String[] args) {
        System.out.println(RectangleService.getPerimeter(15, 10));
        System.out.println(RectangleService.getArea(8, 7));
    }
}
